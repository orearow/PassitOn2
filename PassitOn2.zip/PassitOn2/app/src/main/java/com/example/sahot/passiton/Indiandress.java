package com.example.sahot.passiton;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Indiandress extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_indiandress);

        getSupportActionBar().setTitle("Pass It On");
    }
}
